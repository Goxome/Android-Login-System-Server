<?php
	require_once('anti_ddos/index.php')
?>
<!DOCTYPE html>
<html>
<html lang="pt-br">
<!--===============================================================================================-->
<head>
	<title>Goxome</title>
	<meta charset="UTF-8">
	<meta name="description" content="Ela Admin - HTML5 Admin Template">
	<meta name="viewport" content="width=device-width, initial-scale=1">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
<!--===============================================================================================-->
	<link rel="icon" type="image/png" href="images/icons/favicon.ico"/>
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="heartcore/css/util.css">
	<link rel="stylesheet" type="text/css" href="heartcore/css/main.css">

       <link rel="stylesheet" href="admin-panel/heartcore/css/index-maingx-anim.css">

<!--===============================================================================================-->
<style>
    .wrap-login100 p-t-190 p-b-30 {
        background-color: white;
    }
</style>
<!--===============================================================================================-->	
</head>
<body>
<!--===============================================================================================-->	
	<div class="limiter">
		<div class="container-login100" style="background-image: url('heartcore/images/template/background/goxome-background.png');">
<!--===============================================================================================-->	
					<span class="login100-form-title p-t-20 p-b-45">
						Main Panel
					</span>
    <div class="container">
        <div class="jumbotron">
            <h1 style="text-align: center;">Goxome Official</h1><br>
            <br>
<!--===============================================================================================-->	

            <h1 style="text-align: center;"><a class="login100-form-btn" role="button" href="reseller-panel/index.php" style="text-decoration: none;">Reseller Management System</a><h1><br>
            <h1 style="text-align: center;"><a class="login100-form-btn" role="button" href="admin-panel/index.php" style="text-decoration: none;">Owner Management System</a><h1><br>
	<!--		<h1 style="text-align: center;"><a class="login100-form-btn" role="button" href="web-store/index.php" style="text-decoration: none;">Live Online Store Management</a><h1><br>> -->
	
<!--===============================================================================================-->	
                <h1 style="font-size: 15px;"></h1>
                <p style="font-size: 13px;" class="status-item"><strong>Developed By: <font color='red'>Goxome</font><br></strong></p>
                <p style="font-size: 13px;" class="status-item"><strong>Mail: <font color='white'>GoxomeOfficial@gmail.com</font><br></strong></p>
<!--===============================================================================================-->	
        </div>
					<br>
					<br>
					<br>
					<div class="text-center w-full">
						<a class="text_bottom" href="index.php" style="text-decoration: none;">Server by Goxome</font><br></strong></p>
						</a>
				</form>
	</div>
<!--===============================================================================================-->	
<!--===============================================================================================-->
	<script src="heartcore/js/main.js"></script>

</body>
</html>