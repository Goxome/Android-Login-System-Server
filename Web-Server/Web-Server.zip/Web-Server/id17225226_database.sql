-- phpMyAdmin SQL Dump
-- version 4.9.5
-- https://www.phpmyadmin.net/
--
-- Host: localhost:3306
-- Generation Time: Dec 29, 2021 at 04:26 PM
-- Server version: 10.5.12-MariaDB
-- PHP Version: 7.3.32

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `id17225226_database`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `id` int(11) NOT NULL,
  `username` varchar(50) NOT NULL,
  `password` varchar(50) NOT NULL,
  `name` varchar(50) NOT NULL,
  `email` varchar(50) NOT NULL,
  `gender` varchar(50) NOT NULL,
  `age` int(2) NOT NULL,
  `mobile` varchar(50) NOT NULL,
  `designation` varchar(50) NOT NULL,
  `image` varchar(50) NOT NULL,
  `status` int(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`id`, `username`, `password`, `name`, `email`, `gender`, `age`, `mobile`, `designation`, `image`, `status`) VALUES
(1, 'Goxome', 'c4ca4238a0b923820dcc509a6f75849b', 'Goxome', 'goxomeofficial@gmail.com', 'secret', 0, 'Goxome', 'Goxome', 'img_20201019_131437_617.jpg', 1);

-- --------------------------------------------------------

--
-- Table structure for table `admin2`
--

CREATE TABLE `admin2` (
  `id` int(11) NOT NULL,
  `name` varchar(50) NOT NULL,
  `email` varchar(50) NOT NULL,
  `password` varchar(50) NOT NULL,
  `gender` varchar(50) NOT NULL,
  `mobile` varchar(50) NOT NULL,
  `designation` varchar(50) NOT NULL,
  `image` varchar(50) NOT NULL,
  `status` int(10) NOT NULL,
  `login` varchar(255) NOT NULL,
  `senha` varchar(32) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `admin2`
--

INSERT INTO `admin2` (`id`, `name`, `email`, `password`, `gender`, `mobile`, `designation`, `image`, `status`, `login`, `senha`) VALUES
(1, 'Goxome', 'admin@goxome.com', '23b5cdd79d1308753e152a6de2944dda', 'Female', '000000000', 'Goxome', '2.png', 1, '', '');

-- --------------------------------------------------------

--
-- Table structure for table `deleteduser`
--

CREATE TABLE `deleteduser` (
  `id` int(11) NOT NULL,
  `email` varchar(50) NOT NULL,
  `deltime` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `deleteduser`
--

INSERT INTO `deleteduser` (`id`, `email`, `deltime`) VALUES
(80, 'goxomeofficial@gmail.com', '2021-08-28 13:33:05'),
(81, 'Gayatri@gmail.com', '2021-08-30 12:54:41'),
(82, 'Admin@admin.com', '2021-09-10 22:25:00'),
(83, 'null@f.com', '2021-09-10 22:25:04'),
(84, 'Sona@g.com', '2021-09-10 22:25:08'),
(85, 'L@m.com', '2021-09-10 22:27:41'),
(86, 'Gayatri@gmail.com', '2021-09-12 21:09:45'),
(87, 'X@gma.com', '2021-09-12 21:09:49'),
(88, 'X@gma.com', '2021-09-12 21:09:52'),
(89, 'Cc@m.com', '2021-09-12 21:09:55'),
(90, 'Cc@m.com', '2021-09-12 21:09:58'),
(91, 'Sona@g.com', '2021-09-12 21:51:11'),
(92, 'Sona@g.com', '2021-09-12 21:56:19'),
(93, 'Sona@g.com', '2021-09-12 21:59:30'),
(94, 'Sona@g.com', '2021-09-12 21:59:32'),
(95, 'Sona@g.com', '2021-09-12 22:00:31'),
(96, 'Sona@g.com', '2021-09-12 22:00:33'),
(97, 'Sona@g.com', '2021-09-12 22:01:19'),
(98, 'none@none.com', '2021-09-12 22:06:59'),
(99, 'Sona@goxome.com', '2021-09-12 22:47:13'),
(100, 'Sona@goxome.com', '2021-09-12 22:47:20'),
(101, 'Sona@goxome.com', '2021-09-12 22:47:31'),
(102, 'Sona@goxome.com', '2021-09-12 22:47:35'),
(103, 'Sona@goxome.com', '2021-09-12 22:47:40');

-- --------------------------------------------------------

--
-- Table structure for table `feedback`
--

CREATE TABLE `feedback` (
  `id` int(11) NOT NULL,
  `sender` varchar(50) NOT NULL,
  `reciver` varchar(50) NOT NULL,
  `title` varchar(100) NOT NULL,
  `feedbackdata` varchar(500) NOT NULL,
  `attachment` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `feedback`
--

INSERT INTO `feedback` (`id`, `sender`, `reciver`, `title`, `feedbackdata`, `attachment`) VALUES
(13, 'Gayatri@gmail.com', 'Admin', 'quiero ayuda', 'entero', ' '),
(15, 'Admin', 'Gayatri@gmail.com', '', '', ''),
(16, 'Admin', 'Gayatri@gmail.com', '', '', ''),
(17, 'Admin', 'Gayatri@gmail.com', '', '', ''),
(18, 'Admin', 'Gayatri@gmail.com', '', '', ''),
(19, 'Admin', 'Gayatri@gmail.com', '', 'Thanks for Contacting Us!', ''),
(20, 'Admin', 'Gayatri@gmail.com', '', 'Thanks for Contacting Us!', ''),
(21, 'Sona@goxome.com', 'Admin', 'I want become a reseller', 'Yb', ' '),
(22, 'Sona@goxome.com', 'Admin', 'I want become a reseller', 'Yb', ' '),
(23, 'Sona@goxome.com', 'Admin', 'I want become a reseller', 'Yb', ' '),
(24, 'Sona@goxome.com', 'Admin', 'I want become a reseller', 'Yb', ' '),
(25, 'Sona@goxome.com', 'Admin', 'Hh', 'Gh', ' '),
(26, 'Sona@goxome.com', 'Admin', 'I want become a reseller', 'Yb', ' '),
(27, 'Sona@goxome.com', 'Admin', 'Need help owner', 'Vv', ' '),
(28, 'Sona@goxome.com', 'Admin', 'I want become a reseller', 'Vv', ' '),
(29, 'Sona@goxome.com', 'Admin', 'Help', 'H', '-2576988048867862989_121.jpg'),
(30, 'Sona@goxome.com', 'Admin', 'FcFc', 'C', ' '),
(31, 'Sona@goxome.com', 'Admin', 'Hello', 'T', '1599922632588.png'),
(32, 'Sona@goxome.com', 'Admin', 'Hello', 'G', ' '),
(33, 'Sona@goxome.com', 'Admin', 'Tbnt', 'Vv', '1600851985359.png');

-- --------------------------------------------------------

--
-- Table structure for table `notification`
--

CREATE TABLE `notification` (
  `id` int(11) NOT NULL,
  `notiuser` varchar(50) NOT NULL,
  `notireciver` varchar(50) NOT NULL,
  `notitype` varchar(50) NOT NULL,
  `time` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `notification`
--

INSERT INTO `notification` (`id`, `notiuser`, `notireciver`, `notitype`, `time`) VALUES
(1, 'admin@admin.com', 'Admin', 'Create Account', '2021-08-15 17:11:28'),
(2, 'Admin@admin.com', 'Admin', 'Create Account', '2021-08-15 18:24:22'),
(3, 'Admin@admin.com', 'Admin', 'Create Account', '2021-08-15 18:26:34'),
(4, 'Admin@admin.com', 'Admin', 'Send Feedback', '2021-08-15 18:34:44'),
(5, 'Admin', 'Admin@admin.com', 'Send Message', '2021-08-15 18:35:12'),
(6, 'Admin', 'Admin@admin.com', 'Send Message', '2021-08-15 18:36:24'),
(7, 'Admin@admin.com', 'Admin', 'Send Feedback', '2021-08-15 18:39:22'),
(8, 'Admin@admin.com', 'Admin', 'Send Feedback', '2021-08-15 18:41:15'),
(9, 'Gayatri@gmail.com', 'Admin', 'Create Account', '2021-08-25 12:38:19'),
(10, 'Sona@g.com', 'Admin', 'Create Account', '2021-08-25 12:42:09'),
(11, 'Admin@admin.com', 'Admin', 'Create Account', '2021-08-25 12:44:58'),
(12, 'Sona@g.com', 'Admin', 'Create Account', '2021-08-25 12:46:40'),
(13, 'Sona@g.com', 'Admin', 'Create Account', '2021-08-25 12:49:48'),
(14, 'Sona@g.com', 'Admin', 'Create Account', '2021-08-25 12:51:21'),
(15, 'Sona@g.com', 'Admin', 'Create Account', '2021-08-25 12:54:33'),
(16, 'Sona@g.com', 'Admin', 'Create Account', '2021-08-25 12:56:56'),
(17, '12345', 'Admin', 'Create Account', '2021-08-25 12:59:31'),
(18, '12345', 'Admin', 'Create Account', '2021-08-25 13:00:49'),
(19, '12345', 'Admin', 'Create Account', '2021-08-25 13:01:32'),
(20, '12345', 'Admin', 'Create Account', '2021-08-25 13:01:58'),
(21, '12345', 'Admin', 'Create Account', '2021-08-25 13:02:29'),
(22, 'X@gma.com', 'Admin', 'Create Account', '2021-08-25 13:03:32'),
(23, 'X@gma.com', 'Admin', 'Create Account', '2021-08-25 13:03:57'),
(24, 'X@gma.com', 'Admin', 'Create Account', '2021-08-25 13:04:04'),
(25, 'X@gma.com', 'Admin', 'Create Account', '2021-08-25 13:04:39'),
(26, 'X@gma.com', 'Admin', 'Create Account', '2021-08-25 13:04:53'),
(27, 'X@gma.com', 'Admin', 'Create Account', '2021-08-25 13:05:26'),
(28, 'X@gma.coma', 'Admin', 'Create Account', '2021-08-25 13:05:53'),
(29, 'X@gma.coma', 'Admin', 'Create Account', '2021-08-25 13:06:20'),
(30, 'X@gma.coma', 'Admin', 'Create Account', '2021-08-25 13:07:04'),
(31, 'Gayatri@gmail.com', 'Admin', 'Create Account', '2021-08-25 13:08:22'),
(32, 'FF', 'Admin', 'Create Account', '2021-08-25 13:10:28'),
(33, 'admin@admin.com', 'Admin', 'Create Account', '2021-08-25 13:13:09'),
(34, 'Cc', 'Admin', 'Create Account', '2021-08-25 13:20:30'),
(35, 'Admin@admin.com', 'Admin', 'Send Feedback', '2021-08-25 13:48:05'),
(36, 'g@f.com', 'Admin', 'Create Account', '2021-08-25 14:45:05'),
(37, 'Sona@g.com', 'Admin', 'Create Account', '2021-08-25 19:03:02'),
(38, 'Sona@g.com', 'Admin', 'Create Account', '2021-08-25 21:02:45'),
(39, 'Sona@g.com', 'Admin', 'Create Account', '2021-08-25 21:03:26'),
(40, 'g@f.com', 'Admin', 'Send Feedback', '2021-08-26 17:13:12'),
(41, 'Admin', 'g@f.com', 'Send Message', '2021-08-26 17:13:37'),
(42, 'g@f.com', 'Admin', 'Send Feedback', '2021-08-26 17:13:42'),
(43, 'Admin', 'g@f.com', 'Send Message', '2021-08-26 17:14:47'),
(44, 'Akshay@gmail.com', 'Admin', 'Create Account', '2021-08-26 20:21:50'),
(45, 'admin@m.com', 'Admin', 'Create Account', '2021-08-26 20:28:22'),
(46, 'admin@m.com', 'Admin', 'Create Account', '2021-08-26 20:29:07'),
(47, 'admin@m.com', 'Admin', 'Create Account', '2021-08-26 20:29:26'),
(48, 'admin@m.com', 'Admin', 'Create Account', '2021-08-26 20:31:37'),
(49, 'admin@m.com', 'Admin', 'Create Account', '2021-08-26 20:33:55'),
(50, 'admin@m.com', 'Admin', 'Create Account', '2021-08-26 20:34:16'),
(51, 'Bb', 'Admin', 'Create Account', '2021-08-26 21:26:59'),
(52, 'X@gma.coma', 'Admin', 'Create Account', '2021-08-26 21:27:38'),
(53, 'X@gma.coma', 'Admin', 'Create Account', '2021-08-26 21:27:54'),
(54, 'cuvagoruvit@tovinit.com', 'Admin', 'Create Account', '2021-08-26 21:28:27'),
(55, 'Jina@gmail.com', 'Admin', 'Create Account', '2021-08-26 21:29:17'),
(56, 'Jina@gmail.com', 'Admin', 'Create Account', '2021-08-26 21:29:59'),
(57, 'Jina@gmail.com', 'Admin', 'Create Account', '2021-08-26 21:30:03'),
(58, 'Jina@gmail.com', 'Admin', 'Create Account', '2021-08-26 21:30:08'),
(59, 'Xn@m.com', 'Admin', 'Create Account', '2021-08-26 21:30:34'),
(60, 'Jina@gmail.com', 'Admin', 'Create Account', '2021-08-26 21:30:54'),
(61, 'X@m.com', 'Admin', 'Create Account', '2021-08-26 21:31:17'),
(62, 'X@m.com', 'Admin', 'Create Account', '2021-08-26 21:31:37'),
(63, 'X@m.com', 'Admin', 'Create Account', '2021-08-26 21:31:41'),
(64, 'Cc@m.com', 'Admin', 'Create Account', '2021-08-26 21:32:04'),
(65, 'Cc@m.com', 'Admin', 'Create Account', '2021-08-26 21:32:17'),
(66, 'Cc@m.com', 'Admin', 'Create Account', '2021-08-26 21:33:40'),
(67, 'Cc@m.com', 'Admin', 'Create Account', '2021-08-26 21:33:45'),
(68, 'Cc@m.com', 'Admin', 'Create Account', '2021-08-26 21:34:18'),
(69, 'Cc@m.com', 'Admin', 'Create Account', '2021-08-26 21:34:49'),
(70, 'Cc@m.com', 'Admin', 'Create Account', '2021-08-26 21:35:44'),
(71, 'Cc@m.com', 'Admin', 'Create Account', '2021-08-26 21:36:54'),
(72, 'Cc@m.com', 'Admin', 'Create Account', '2021-08-26 21:37:34'),
(73, 'Cc@m.com', 'Admin', 'Create Account', '2021-08-26 21:38:36'),
(74, 'Manish@sax.com', 'Admin', 'Create Account', '2021-08-28 12:39:08'),
(75, 'Manish@sax.com', 'Admin', 'Create Account', '2021-08-28 12:44:30'),
(76, 'X@m.com', 'Admin', 'Create Account', '2021-08-28 12:44:55'),
(77, 'b@g.com', 'Admin', 'Create Account', '2021-08-28 13:10:17'),
(78, 'b@g.com', 'Admin', 'Create Account', '2021-08-28 13:11:01'),
(79, 'b@g.com', 'Admin', 'Create Account', '2021-08-28 13:11:09'),
(80, 'Abc@m.com', 'Admin', 'Create Account', '2021-08-28 13:11:32'),
(81, 'Abc@m.com', 'Admin', 'Create Account', '2021-08-28 13:13:22'),
(82, 'Bbb@n', 'Admin', 'Create Account', '2021-08-28 13:13:46'),
(83, 'Bbb@n', 'Admin', 'Create Account', '2021-08-28 13:14:33'),
(84, 'xx@f.com', 'Admin', 'Create Account', '2021-08-28 13:14:54'),
(85, 'b@g.com', 'Admin', 'Create Account', '2021-08-28 13:17:08'),
(86, 'b@g.com', 'Admin', 'Create Account', '2021-08-28 13:18:39'),
(87, 'Bbb@n', 'Admin', 'Create Account', '2021-08-28 13:18:54'),
(88, 'Bbb@n', 'Admin', 'Create Account', '2021-08-28 13:19:49'),
(89, 'goxomeofficial@gmail.com', 'Admin', 'Create Account', '2021-08-28 13:20:13'),
(90, 'goxomeofficial@gmail.com', 'Admin', 'Create Account', '2021-08-28 13:23:13'),
(91, 'L@m.com', 'Admin', 'Create Account', '2021-08-28 13:23:32'),
(92, 'L@m.com', 'Admin', 'Create Account', '2021-08-28 13:24:18'),
(93, 'Sona@g.com', 'Admin', 'Create Account', '2021-08-28 13:24:43'),
(94, 'Gayatri@gmail.com', 'Admin', 'Create Account', '2021-08-29 11:16:20'),
(95, 'Gayatri@gmail.com', 'Admin', 'Create Account', '2021-08-29 11:16:48'),
(96, 'Gayatri@gmail.com', 'Admin', 'Send Feedback', '2021-08-29 11:21:09'),
(97, 'Admin', 'Gayatri@gmail.com', 'Send Message', '2021-08-29 11:22:01'),
(98, 'X@gma.com', 'Admin', 'Create Account', '2021-08-30 12:52:52'),
(99, 'Gayatri@gmail.com', 'Admin', 'Send Feedback', '2021-08-30 12:56:25'),
(100, 'Admin', 'Gayatri@gmail.com', 'Send Message', '2021-08-30 12:57:07'),
(101, 'Admin', 'Gayatri@gmail.com', 'Send Message', '2021-09-11 08:23:56'),
(102, 'Admin', 'Gayatri@gmail.com', 'Send Message', '2021-09-11 08:25:05'),
(103, 'Admin', 'Gayatri@gmail.com', 'Send Message', '2021-09-11 08:25:33'),
(104, 'Admin', 'Gayatri@gmail.com', 'Send Message', '2021-09-11 08:26:25'),
(105, 'Admin', 'Gayatri@gmail.com', 'Send Message', '2021-09-11 10:03:05'),
(106, 'Admin', 'Gayatri@gmail.com', 'Send Message', '2021-09-11 10:03:08'),
(107, 'Sona@none.com', 'Admin', 'Create Account', '2021-09-12 22:07:47'),
(108, 'Sona@none.com', 'Admin', 'Create Account', '2021-09-12 22:08:05'),
(109, 'X', 'Admin', 'Create Account', '2021-09-12 22:11:59'),
(110, 'X', 'Admin', 'Create Account', '2021-09-12 22:13:54'),
(111, 'X@gma.com', 'Admin', 'Create Account', '2021-09-12 22:16:58'),
(112, 'Sona@goxome.com', 'Admin', 'Create Account', '2021-09-12 22:46:32'),
(113, 'Sona@goxome.com', 'Admin', 'Send Feedback', '2021-09-12 23:15:04'),
(114, 'Sona@goxome.com', 'Admin', 'Send Feedback', '2021-09-12 23:19:07'),
(115, 'Sona@goxome.com', 'Admin', 'Send Feedback', '2021-09-12 23:19:09'),
(116, 'Sona@goxome.com', 'Admin', 'Send Feedback', '2021-09-12 23:19:35'),
(117, 'Sona@goxome.com', 'Admin', 'Send Feedback', '2021-09-12 23:19:45'),
(118, 'Sona@goxome.com', 'Admin', 'Send Feedback', '2021-09-12 23:20:47'),
(119, 'Sona@goxome.com', 'Admin', 'Send Feedback', '2021-09-12 23:21:06'),
(120, 'Sona@goxome.com', 'Admin', 'Send Feedback', '2021-09-12 23:24:52'),
(121, 'Sona@goxome.com', 'Admin', 'Send Feedback', '2021-09-12 23:24:58'),
(122, 'Sona@goxome.com', 'Admin', 'Send Feedback', '2021-09-12 23:25:58'),
(123, 'Sona@goxome.com', 'Admin', 'Send Feedback', '2021-09-12 23:26:25'),
(124, 'Sona@goxome.com', 'Admin', 'Send Feedback', '2021-09-12 23:28:08'),
(125, 'Sona@goxome.com', 'Admin', 'Send Feedback', '2021-09-12 23:28:48'),
(126, 'Sona@goxome.com', 'Admin', 'Send Feedback', '2021-09-12 23:29:11'),
(127, 'Sona@goxome.com', 'Admin', 'Send Feedback', '2021-09-12 23:31:07');

-- --------------------------------------------------------

--
-- Table structure for table `tokens`
--

CREATE TABLE `tokens` (
  `Username` varchar(20) NOT NULL,
  `Token` varchar(12) NOT NULL,
  `Seller` text NOT NULL,
  `StartDate` timestamp NULL DEFAULT NULL,
  `EndDate` timestamp NULL DEFAULT NULL,
  `UID` varchar(60) DEFAULT NULL,
  `UID2` varchar(60) DEFAULT NULL,
  `UID3` varchar(60) DEFAULT NULL,
  `Devices` int(11) NOT NULL,
  `Expiry` int(6) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `tokens`
--

INSERT INTO `tokens` (`Username`, `Token`, `Seller`, `StartDate`, `EndDate`, `UID`, `UID2`, `UID3`, `Devices`, `Expiry`) VALUES
('Sona', 'chp66b%u9t#y', 'Yhyh', '2021-09-23 19:15:00', '2021-09-26 04:45:00', 'bdb550f5aa1b32c293ca8c2b8fd2e3cc', NULL, NULL, 1, 2),
('Sona', 'ltvfouc1bzk*', 'F', '2021-09-24 08:11:00', '2021-09-28 17:40:00', 'c8a22f48385a31be83b19a8fdeffeb6c', NULL, NULL, 1, 2),
('Sona', 'ltvfouc1bzk*', 'F', '2021-09-24 08:24:00', '2021-09-28 17:40:00', NULL, NULL, NULL, 1, 2),
('Hell', 'puq6fpv3%zw6', 'Devil', '2021-09-28 23:45:00', '2026-09-29 09:15:00', 'e2db842b1c0f37c7a0340695c20ef83b', NULL, NULL, 1, 2);

-- --------------------------------------------------------

--
-- Table structure for table `userpwd`
--

CREATE TABLE `userpwd` (
  `Username` varchar(20) NOT NULL,
  `Password` varchar(8) NOT NULL,
  `Seller` text NOT NULL,
  `StartDate` timestamp NULL DEFAULT NULL,
  `EndDate` timestamp NULL DEFAULT NULL,
  `UID` varchar(60) DEFAULT NULL,
  `Expiry` int(6) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `userpwd`
--

INSERT INTO `userpwd` (`Username`, `Password`, `Seller`, `StartDate`, `EndDate`, `UID`, `Expiry`) VALUES
('Sona', '123', '', '2021-09-08 11:54:00', '2021-09-08 21:24:00', NULL, 2),
('Sona', '123', '', '2021-09-08 11:54:00', '2021-09-08 21:24:00', NULL, 2),
('Ashwathyi', 'Bb', '', '2021-09-08 12:00:00', '2021-09-08 19:30:00', NULL, 2),
('Ashwathyi', 'Hh', 'Gg', '2021-09-08 12:03:00', '2021-09-08 19:33:00', NULL, 2);

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `name` varchar(50) NOT NULL,
  `email` varchar(50) NOT NULL,
  `password` varchar(50) NOT NULL,
  `gender` varchar(50) NOT NULL,
  `mobile` varchar(50) NOT NULL,
  `designation` varchar(50) NOT NULL,
  `image` varchar(50) NOT NULL,
  `status` int(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `name`, `email`, `password`, `gender`, `mobile`, `designation`, `image`, `status`) VALUES
(25, 'Angel', 'angel1101111@gmail.com', '17540aef7b8470cc3ea8b2b9046af3b6', 'Female', '0000000000', 'X', 'zepeto_1612909662095.jpg', 0),
(27, 'Goxome', 'admin@goxome.com', 'e0323a9039add2978bf5b49550572c7c', 'Female', '0000000000', 'Goxome', 'img_20190703_182418_858.jpg', 0),
(63, 'Sona', 'Sona@goxome.com', '9ae2be73b58b565bce3e47493a56e26a', 'Female', '0000000000', 'Goxome', 'pubg-wallpaper-v_4.jpeg', 1);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `deleteduser`
--
ALTER TABLE `deleteduser`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `feedback`
--
ALTER TABLE `feedback`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `notification`
--
ALTER TABLE `notification`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `deleteduser`
--
ALTER TABLE `deleteduser`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=104;

--
-- AUTO_INCREMENT for table `feedback`
--
ALTER TABLE `feedback`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=34;

--
-- AUTO_INCREMENT for table `notification`
--
ALTER TABLE `notification`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=128;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=64;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
