<?php
session_start();
include('includes/config.php');
if(isset($_POST['login']))
{
$status='1';
$email=$_POST['username'];
$password=md5($_POST['password']);
$sql ="SELECT email,password FROM users WHERE email=:email and password=:password and status=(:status)";
$query= $dbh -> prepare($sql);
$query-> bindParam(':email', $email, PDO::PARAM_STR);
$query-> bindParam(':password', $password, PDO::PARAM_STR);
$query-> bindParam(':status', $status, PDO::PARAM_STR);
$query-> execute();
$results=$query->fetchAll(PDO::FETCH_OBJ);
if($query->rowCount() > 0)
{
$_SESSION['alogin']=$_POST['username'];
echo "<script type='text/javascript'> document.location = 'profile.php'; </script>";
} else{
  
  echo "<script>alert('Invalid Details Or Account Not Confirmed');</script>";

}

}

?>
<html lang="en">
<head><meta charset="euc-jp">
	<title>Login</title>
	
	<meta name="viewport" content="width=device-width, initial-scale=1">
<!--===============================================================================================-->	
	<link rel="icon" type="image/png" href="images2/icons/favicon.ico"/>
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="vendor2/bootstrap/css/bootstrap.min.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="fonts2/font-awesome-4.7.0/css/font-awesome.min.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="fonts2/iconic/css/material-design-iconic-font.min.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="vendor2/animate/animate.css">
<!--===============================================================================================-->	
	<link rel="stylesheet" type="text/css" href="vendor2/css-hamburgers/hamburgers.min.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="vendor2/animsition/css/animsition.min.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="vendor2/select2/select2.min.css">
<!--===============================================================================================-->	
	<link rel="stylesheet" type="text/css" href="vendor2/daterangepicker/daterangepicker.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="css2/util.css">
	<link rel="stylesheet" type="text/css" href="css2/main.css">
	
<!--===============================================================================================-->
</head>
<body>

		<div class="container-login100" style="background-image: url('/reseller-panel/images/template/background/goxome-background.png');">
		<!--	<div class="wrap-login100 p-l-55 p-r-55 p-t-65 p-b-54"> -->
				<form action="<?php echo $_SERVER['PHP_SELF']; ?>" method="POST" class="login100-form validate-form" >
					

					<span class="login100-form-title p-b-49">Login System</span>
					
					
					
					<?php 
if(!empty($erros)):
	foreach($erros as $erro):
		echo $erro;
	endforeach;
endif;
?>

				
	
	


					
	<div class="login-page bk-img">
		<div class="form-content">
			<div class="container">
				<div class="row">
					<div class="col-md-6 col-md-offset-3">
						<h1 class="text-center text-bold mt-4x">Reseller Login</h1>
						<div class="well row pt-2x pb-3x bk-light">
							<div class="col-md-8 col-md-offset-2">
								<form method="post">

									
	                       <div class="wrap-input100 validate-input m-b-23" data-validate = "Place the Email!">
						    <span class="label-input100">Email</span>
						<input class="input100" type="text" placeholder="Username" name="username" class="form-control mb" value="<?php echo isset($_COOKIE['login']) ? $_COOKIE['login'] : '' ?>">
     <span class="focus-input100" data-symbol="&#xf206;"></span>
					</div>







							    	<div class="wrap-input100 validate-input" data-validate="Coloque a senha!">
									<span class="label-input100">Password</span>
									<input class="input100" type="password" placeholder="Password" name="password" class="form-control mb" required>
									<span class="focus-input100" data-symbol="&#xf190;"></span>
									</div>
									
				
									
									 <br></br>
						<div class="container-login100-form-btn">
						   
						<div class="wrap-login100-form-btn">
							<div class="login100-form-bgbtn"></div>
							<button class="login100-form-btn" type="submit" name="login">


								Login
							</button>
						</div>
									
								</form>
								<br>
								<div>
									<br>
								<p>Don't Have an Account? <a href="register-requested.php" >Request</a></p>
							    <p>Contact Us <a href="https://t.me/Goxome" >Check</a></p>
							 <!--<p>Admin Panel <a href="/admin/index.php" >Check</a></p> -->
								
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
	      

					<br>
					<br>


					<div class="text-center w-full">
						<a class="wrap-login100-form-btn" href="index.php" style="color:#AFA; style="text-decoration: none;">Server by Goxome</font><br></strong></p>	
						</a>
			
	</div>

	
<!--===============================================================================================-->	
	<script src="vendor2/jquery/jquery-3.2.1.min.js"></script>
<!--===============================================================================================-->
	<script src="vendor2/bootstrap/js/popper.js"></script>
	<script src="vendor2/bootstrap/js/bootstrap.min.js"></script>
<!--===============================================================================================-->
	<script src="vendor2/select2/select2.min.js"></script>
<!--===============================================================================================-->
	<script src="js/main.js"></script>

</body>
</html>








