<?php
// Sessão
session_start();
// Verificação
include('includes/config.php');
if(!isset($_SESSION['logado'])):
    header('Location: index');
endif;
?>

<!doctype html>
<!--[if lt IE 7]>      <html class="no-js lt-ie9 lt-ie8 lt-ie7" lang=""> <![endif]-->
<!--[if IE 7]>         <html class="no-js lt-ie9 lt-ie8" lang=""> <![endif]-->
<!--[if IE 8]>         <html class="no-js lt-ie9" lang=""> <![endif]-->
<!--[if gt IE 8]><!--> <html class="no-js" lang="en"> <!--<![endif]-->
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>Dashboard - GOXOME</title>
    <meta name="description" content="Ela Admin - HTML5 Admin Template">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <link rel="apple-touch-icon" href="https://i.imgur.com/QRAUqs9.png">
    <link rel="shortcut icon" href="images/icon.png">

    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/normalize.css@8.0.0/normalize.min.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.1.3/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/font-awesome@4.7.0/css/font-awesome.min.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/gh/lykmapipo/themify-icons@0.1.2/css/themify-icons.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/pixeden-stroke-7-icon@1.2.3/pe-icon-7-stroke/dist/pe-icon-7-stroke.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/flag-icon-css/3.2.0/css/flag-icon.min.css">
    <link rel="stylesheet" href="heartcore/assets/css/cs-skin-elastic.css">
    <link rel="stylesheet" href="heartcore/assets/css/style.css">
    
    <!-- <script type="text/javascript" src="https://cdn.jsdelivr.net/html5shiv/3.7.3/html5shiv.min.js"></script> -->
    <link href="https://cdn.jsdelivr.net/npm/chartist@0.11.0/dist/chartist.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/jqvmap@1.5.1/dist/jqvmap.min.css" rel="stylesheet">

    <link href="https://cdn.jsdelivr.net/npm/weathericons@2.1.0/css/weather-icons.css" rel="stylesheet" />
    <link href="https://cdn.jsdelivr.net/npm/fullcalendar@3.9.0/dist/fullcalendar.min.css" rel="stylesheet" />

</head>

<body>
    <!-- Left Panel -->
    <aside id="left-panel" class="left-panel">
        <nav class="navbar navbar-expand-sm navbar-default">
            <div id="main-menu" class="main-menu collapse navbar-collapse">
                <ul class="nav navbar-nav">
                    <li class="active">
                        <a href="dashboard"><a href="dashboard"><i class="menu-icon fa fa-desktop"></i>Dashboard </a>
                        
                        
                      <li class="menu-title">UserName Management</li><!-- /.menu-title -->

			
                    <li class="menu-item-has-children dropdown">
                        <a href="#" class="dropdown-toggle" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false"> <i class="menu-icon fa fa-globe"></i>Server Connection</a>
                        <ul class="sub-menu children dropdown-menu">
                                 <li><i class="fa fa-globe"></i><a href="lipstick-core/connections/connection_usr">Connection USR</a></li>
                            <li><i class="fa fa-globe"></i><a href="lipstick-core/connections/connection_tkn">Connection TKN</a></li>
                            <li><i class="fa fa-globe"></i><a href="lipstick-core/connections/connection_lsn">Connection LSN</a></li>
                        </ul>


                    </li>
                    <li class="menu-title">UserName Management</li><!-- /.menu-title -->

			
                    <li class="menu-item-has-children dropdown">
                        <a href="#" class="dropdown-toggle" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false"> <i class="menu-icon fa fa-user"></i>UserName Manager</a>
                        <ul class="sub-menu children dropdown-menu">
                                 <li><i class="fa fa-users"></i><a href="registration-users/users-list-usr">CheckList</a></li>
                            <li><i class="fa fa-user"></i><a href="registration-users/register-user-usr">Registeration</a></li>
                            <li><i class="fa fa-user-plus"></i><a href="add-days">Update Days</a></li>
                            <li><i class="fa fa-unlock"></i><a href="trial">Trail</a></li>
                        </ul>
            
                                <li class="menu-title">Token Management</li><!-- /.menu-title -->

			
                    <li class="menu-item-has-children dropdown">
                        <a href="#" class="dropdown-toggle" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false"> <i class="menu-icon fa fa-user"></i>TokenKey Manager</a>
                        <ul class="sub-menu children dropdown-menu">
                                 <li><i class="fa fa-users"></i><a href="registration-users/users-list-tkn">CheckList</a></li>
                            <li><i class="fa fa-user"></i><a href="registration-users/register-user-tkn">Registeration</a></li>
                            <li><i class="fa fa-user-plus"></i><a href="add-days">Update Days</a></li>
                            <li><i class="fa fa-unlock"></i><a href="trial">Trail</a></li>
                        </ul>
                                            <li class="menu-title">Reseller Management</li><!-- /.menu-title -->

			
                    <li class="menu-item-has-children dropdown">
                        <a href="#" class="dropdown-toggle" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false"> <i class="menu-icon fa fa-users"></i>Sell-ID Manager</a>
                        <ul class="sub-menu children dropdown-menu">
                                 <li><i class="fa fa-users"></i><a href="admin-sl/userlist">CheckList</a></li>
                            <li><i class="fa fa-user"></i><a href="admin-sl/register-reseller">Registeration</a></li>
                            <li><i class="fa fa-user-plus"></i><a href="admin-sl/feedback">Feed-Inbox</a></li>
                            <li><i class="fa fa-unlock"></i><a href="admin-sl/deleteduser">Deleted UsersList</a></li>
                        </ul>
                
                          <li class="menu-title">Other Management</li><!-- /.menu-title -->

                			
                    <li class="menu-item-has-children dropdown">
                        <a href="#" class="dropdown-toggle" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false"> <i class="menu-icon fa fa-users"></i>Ads AutoToken Manager</a>
                        <ul class="sub-menu children dropdown-menu">
                                 <li><i class="fa fa-users"></i><a href="admin-sl/userlist">CheckList</a></li>
                            <li><i class="fa fa-user"></i><a href="admin-sl/register-reseller">Registeration</a></li>
                            <li><i class="fa fa-user-plus"></i><a href="admin-sl/feedback">Feed-Inbox</a></li>
                            <li><i class="fa fa-unlock"></i><a href="admin-sl/deleteduser">Deleted UsersList</a></li>
                        </ul>
                
                
                                <li class="menu-title">Other Management</li><!-- /.menu-title -->

                    <!-- Other Funtions -->

                    <li class="menu-item-has-children dropdown">
                        <a href="#" class="dropdown-toggle" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false"> <i class="menu-icon fa fa-money"></i>LibraryOnlineSystem</a>
                        <ul class="sub-menu children dropdown-menu">
                            <li><i class="fa fa-unlock-alt"></i><a href="tables-basic.html">Chat Online</a></li>
                            <li><i class="fa fa-unlock-alt"></i><a href="tables-data.html">Lib Online</a></li>
                            <li><i class="fa fa-unlock-alt"></i><a href="tables-data.html">Upload Lib</a></li>
                            <li><i class="fa fa-unlock-alt"></i><a href="tables-data.html">Status Lib</a></li>
                        </ul>




                    <li class="menu-title">Outras Ações</li><!-- /.menu-title -->
                    <li class="menu-item-has-children dropdown">
                        <a href="#" class="dropdown-toggle" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false"> <i class="menu-icon fa fa-plus-square"></i>Mais</a>
                        <ul class="sub-menu children dropdown-menu">
                            <li><i class="menu-icon fa fa-info"></i><a href="dadosgerais.php">Dados / Configurações</a></li>
                              <li><i class="menu-icon fa fa-bar-chart"></i><a href="act5.php">Limpar Logs</a></li>
                              <li><i class="menu-icon fa fa-upload"></i><a href="LibOn/LibOnline.php">Lib Online</a></li>
                              <li><i class="menu-icon fa fa-upload"></i><a href="DexOnline/Xloader.php">Dex Online</a></li>
                        
                             <li><i class="menu-icon fa fa-sign-in"></i><a href="logout.php">Log Out</a></li>
                    
                      
             

  
                        
                        </ul>
                    </li>


                    
                </ul>
            </div><!-- /.navbar-collapse -->
        </nav>
    </aside>
    <!-- /#left-panel -->
    <!-- Right Panel -->
    <div id="right-panel" class="right-panel">
        <!-- Header-->
        <header id="header" class="header">
            <div class="top-left">
                <div class="navbar-header">
                    <a class="navbar-brand" href="./"><img src="images/hackersteam.png" alt="Logo"></a>
                    <a class="navbar-brand hidden" href="./"><img src="images/logo2.png" alt="Logo"></a>
                    <a id="menuToggle" class="menutoggle"><i class="fa fa-bars"></i></a>
                </div>
            </div>
            <div class="top-right">
                        
                    
                <div class="header-menu">
                    <div class="header-left">
                        <button class="search-trigger"><i class="fa fa-search"></i></button>
                        <div class="form-inline">
                            <form class="search-form">
                                <input class="form-control mr-sm-2" type="text" placeholder="Search ..." aria-label="Search">
                                <button class="search-close" type="submit"><i class="fa fa-close"></i></button>
                            </form>
                        </div>

                    <div class="user-area dropdown float-right">
                        <a href="#" class="dropdown-toggle active" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                        

       <?php
		$sql = "SELECT * from admin;";
		$query = $dbh -> prepare($sql);
		$query->execute();
		$result=$query->fetch(PDO::FETCH_OBJ);
		$cnt=1;	
?>


                            
                            
 
                            
                       
                         <img class="user-avatar rounded-circle" alt="User Avatar" src="images/avatar/<?php echo htmlentities($result->image);?>">
                                             </a>
                           <div class="user-menu dropdown-menu">
                            <a class="nav-link" href="heartcore/profile.php"><i class="fa fa-user"></i>My Profile</a>

                            <a class="nav-link" href="heartcore/notification.php"><i class="fa fa-bell"></i>Notifications <sup style="color:red">*</sup></a>
                            
                            

                            <a class="nav-link" href="#"><i class="fa fa-cog"></i>Settings</a>

                            <a class="nav-link" href="logout.php"><i class="menu-icon fa fa-sign-out"></i>Logout</a>

                        </div>
                    </div>

                </div>
            </div>
        </header>
        <!-- /#header -->
        <!-- Content -->
        <div class="content">
            <!-- Animated -->
            <div class="animated fadeIn">
                <!-- Widgets  -->
                <div class="row">
                
                    <div class="col-lg-3 col-md-6">
                        <div class="card">
                            <div class="card-body">
                                <div class="stat-widget-five">
                                    <div class="stat-icon dib flat-color-1">
                                               <!-- / <i class="pe-7s-cash"></i>  -->
                                        <i class="pe-7s-chat"></i> 
                                    </div>
                                    <div class="stat-content">
                                        <div class="text-left dib">
                                            <div class="stat-text"><span class="count"></span></div>
                                            <div class="stat-heading">Deleted Users</div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

<?php 
$sql ="SELECT id from users";
$query = $dbh -> prepare($sql);
$query->execute();
$results=$query->fetchAll(PDO::FETCH_OBJ);
$bg=$query->rowCount();
?>
			

                    <div class="col-lg-3 col-md-6">
                        <div class="card">
                            <div class="card-body">
                                <div class="stat-widget-five">
                                    <div class="stat-icon dib flat-color-2">
                                        <i class="pe-7s-browser"></i>
                                    </div>
                                    <div class="stat-content">
                                        <div class="text-left dib">
                                            <div class="stat-text"><span class="count">						
<?php echo htmlentities(2)*($bg);?></span></div>
                                            <div class="stat-heading">Token Users</div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

								
								
<?php 
$sql ="SELECT id from users";
$query = $dbh -> prepare($sql);
$query->execute();
$results=$query->fetchAll(PDO::FETCH_OBJ);
$bg=$query->rowCount();
?>
										
								
                    <div class="col-lg-3 col-md-6">
                        <div class="card">
                            <div class="card-body">
                                <div class="stat-widget-five">
                                
                                    <div class="stat-icon dib flat-color-3">

                                                <i class="pe-7s-cart"></i>
                                    </div>
                                    <div class="stat-content">
                                        <div class="text-left dib">
                                            <div class="stat-text"><span class="count">						
<?php echo htmlentities($bg);?></span></div>
                                            <div class="stat-heading">Resellers Users</div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

<?php   // this code is use to insert the form details and register and expiration date
//include 'DB.php';
include 'lipstick-core/Global.php';
?>

                    <div class="col-lg-3 col-md-6">
                        <div class="card">
                            <div class="card-body">
                                <div class="stat-widget-five">
                                    <div class="stat-icon dib flat-color-4">
                                        <i class="pe-7s-users"></i>
                                    </div>
                                    <div class="stat-content">
                                        <div class="text-left dib">
                                            <div class="stat-text"><span class="count"><?php 
$sql12 = "SELECT COUNT(*) FROM tokens";
    $resulto = mysqli_query($conn,$sql12);
    $rows1 = mysqli_fetch_row($resulto);
    echo $rows1[0];
?></span></div>
                                            <div class="stat-heading">USRPWD Users</div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <!-- /Widgets -->






<body>






                <!--  Traffic  -->
                <div class="row">
                    <div class="col-lg-12">
                        <div class="card">
                                <div class="card-header">
                                    <i class="mr-2 fa fa-align-justify"></i>
                                    <strong class="card-title" v-if="headerText">Status Features</strong>
                                </div>

                                <div class="card-body">

                <!-- Shop -->
                <table class="table table-striped table-valign-middle">
                  <thead>
                  <tr>
                    <th>Category</th>
                    <th>Status</th>
                    <th>Action</th>
                  </tr>
                  </thead>
                  <tbody>
                  <tr>
                    <td>
                      <img class="rounded-circle" size="18" src="./heartcore/images/dashboard/store.png" alt="">
                       Store Post
                    </td>
                    <td><span class="badge badge-info">In-line</span></td>
                    <td><a href="/web-store/admin/admin.php" link="nav-link"><button type="button" class="btn btn-outline-primary">Update</button></td>
                  </tr>
                  <tr>
                    <td>
                      <img class="rounded-circle" src="./heartcore/images/dashboard/lib_online.png" alt="">
                       Lib Online
                    </td>
                    <td><span class="badge badge-success">Online</span></td>
                    <td><a href="" link="nav-link"><button type="button" class="btn btn-outline-primary">Upload</button></td>
                  </tr>

                  <tr>
                    <td>
                      <img class="rounded-circle" src="./heartcore/images/dashboard/dex_online.png" alt="">
                      Dex Online
                    </td>
                    <td><span class="badge badge-danger">Offline</span></td>
                    <td><button type="button" class="btn btn-outline-primary">Upload</button></td>
                  </tr>  
                  </tbody>
                </table>
                <!-- Shop -->           

                                    </div> <!-- /.card-body -->
                                </div>
                            </div> <!-- /.row -->
                            <div class="card-body"></div>
                        </div>
                    </div><!-- /# column -->
                </div>
                <!--  /Traffic -->
                <div class="clearfix"></div>
                <!-- Orders -->
                
            
        <!-- /.content -->
        <div class="clearfix"></div>
        <!-- Footer -->
        <footer class="site-footer">
            <div class="footer-inner bg-white">
                <div class="row">
                    <div class="col-sm-6"><B>
                        Copyright &copy; <a href="https://colorlib.com"> 2021 Goxome
                    </div>
                </div>
            </div>
        </footer>
        <!-- /.site-footer -->
    </div>
    <!-- /#right-panel -->

    <!-- Scripts -->
    <script src="https://cdn.jsdelivr.net/npm/jquery@2.2.4/dist/jquery.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.14.4/dist/umd/popper.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.1.3/dist/js/bootstrap.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/jquery-match-height@0.7.2/dist/jquery.matchHeight.min.js"></script>
    <script src="heartcore/assets/js/main.js"></script>

    <!--  Chart js -->
    <script src="https://cdn.jsdelivr.net/npm/chart.js@2.7.3/dist/Chart.bundle.min.js"></script>

    <!--Chartist Chart-->
    <script src="https://cdn.jsdelivr.net/npm/chartist@0.11.0/dist/chartist.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/chartist-plugin-legend@0.6.2/chartist-plugin-legend.min.js"></script>

    <script src="https://cdn.jsdelivr.net/npm/jquery.flot@0.8.3/jquery.flot.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/flot-pie@1.0.0/src/jquery.flot.pie.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/flot-spline@0.0.1/js/jquery.flot.spline.min.js"></script>

    <script src="https://cdn.jsdelivr.net/npm/simpleweather@3.1.0/jquery.simpleWeather.min.js"></script>
    <script src="heartcore/assets/js/init/weather-init.js"></script>

    <script src="https://cdn.jsdelivr.net/npm/moment@2.22.2/moment.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/fullcalendar@3.9.0/dist/fullcalendar.min.js"></script>
    <script src="heartcore/assets/js/init/fullcalendar-init.js"></script>

    <!--Local Stuff-->

</body>
</html>
