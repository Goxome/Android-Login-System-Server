<?php
$maintenance = false;
$latestver = "v1.2";
$latestverlink = "Release/PUBGPatcher-v1.2.apk";