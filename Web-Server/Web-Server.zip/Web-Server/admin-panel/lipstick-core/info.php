<?php 

$tabela = 'tokens33';
$tabela2 = 'usuarios33';
$tabela3 = 'vendedores33';
$tabela4 = 'banidos33';
$sessao = 'logado33';
$static = 'login';

?>