<?php
session_start();
error_reporting(0);
include('../includes/config.php');
if(!isset($_SESSION['logado'])):
    header('Location: index');
endif;


if(isset($_POST['submit']))
  {	
	$file = $_FILES['image']['name'];
	$file_loc = $_FILES['image']['tmp_name'];
	$folder="images/avatar/";
	$new_file_name = strtolower($file);
	$final_file=str_replace(' ','-',$new_file_name);
	
	$name=$_POST['name'];
	$email=$_POST['email'];
	$gender=$_POST['gender'];
	$age=$_POST['age'];
	$mobileno=$_POST['mobile'];
	$designation=$_POST['designation'];
	$idedit=$_POST['editid'];
	$image=$_POST['image'];

	if(move_uploaded_file($file_loc,$folder.$final_file))
		{
			$image=$final_file;
		}

	$sql="UPDATE admin SET name=(:name), gender=(:gender), age=(:age), email=(:email), mobile=(:mobileno), designation=(:designation), Image=(:image) WHERE id=(:idedit)";
	$query = $dbh->prepare($sql);
	$query-> bindParam(':name', $name, PDO::PARAM_STR);
	$query-> bindParam(':email', $email, PDO::PARAM_STR);
	$query-> bindParam(':gender', $gender, PDO::PARAM_STR);
	$query-> bindParam(':age', $age, PDO::PARAM_STR);
	$query-> bindParam(':mobileno', $mobileno, PDO::PARAM_STR);
	$query-> bindParam(':designation', $designation, PDO::PARAM_STR);
	$query-> bindParam(':image', $image, PDO::PARAM_STR);
	$query-> bindParam(':idedit', $idedit, PDO::PARAM_STR);
	$query->execute();
	$msg="Information Updated Successfully";
}    
?>


<!doctype html>
<html lang="en" class="no-js">

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>Dashboard - Hackers Team</title>
    <meta name="description" content="Ela Admin - HTML5 Admin Template">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <link rel="apple-touch-icon" href="https://i.imgur.com/QRAUqs9.png">
    <link rel="shortcut icon" href="../images/icon.png">

    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/normalize.css@8.0.0/normalize.min.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.1.3/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/font-awesome@4.7.0/css/font-awesome.min.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/gh/lykmapipo/themify-icons@0.1.2/css/themify-icons.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/pixeden-stroke-7-icon@1.2.3/pe-icon-7-stroke/dist/pe-icon-7-stroke.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/flag-icon-css/3.2.0/css/flag-icon.min.css">
    <link rel="stylesheet" href="../heartcore/assets/css/cs-skin-elastic.css">
    <link rel="stylesheet" href="../heartcore/assets/css/style.css">
    <link rel="stylesheet" href="../heartcore/css/registration-token.css">
    
    <!-- <script type="text/javascript" src="https://cdn.jsdelivr.net/html5shiv/3.7.3/html5shiv.min.js"></script> -->
    <link href="https://cdn.jsdelivr.net/npm/chartist@0.11.0/dist/chartist.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/jqvmap@1.5.1/dist/jqvmap.min.css" rel="stylesheet">

    <link href="https://cdn.jsdelivr.net/npm/weathericons@2.1.0/css/weather-icons.css" rel="stylesheet" />
    <link href="https://cdn.jsdelivr.net/npm/fullcalendar@3.9.0/dist/fullcalendar.min.css" rel="stylesheet" />

</head>

<body>
    <!-- Left Panel -->
    <aside id="left-panel" class="left-panel">
        <nav class="navbar navbar-expand-sm navbar-default">
            <div id="main-menu" class="main-menu collapse navbar-collapse">
                <ul class="nav navbar-nav">
                    <li class="active">
                        <a href="dashboard"><a href="dashboard"><i class="menu-icon fa fa-desktop"></i>Dashboard </a>
                        
                        
                      <li class="menu-title">UserName Management</li><!-- /.menu-title -->

			
                    <li class="menu-item-has-children dropdown">
                        <a href="#" class="dropdown-toggle" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false"> <i class="menu-icon fa fa-globe"></i>Server Connection</a>
                        <ul class="sub-menu children dropdown-menu">
                                 <li><i class="fa fa-globe"></i><a href="connection_usr">Connection USR</a></li>
                            <li><i class="fa fa-globe"></i><a href="connection_tkn">Connection TKN</a></li>
                            <li><i class="fa fa-globe"></i><a href="connection_lsn">Connection LSN</a></li>
                        </ul>

                    <li class="">
                        <a href="index.php"> <i class="menu-icon fa fa-sellsy"></i>User Analytics</a>


                    </li>
                    <li class="menu-title">UserName Management</li><!-- /.menu-title -->

			
                    <li class="menu-item-has-children dropdown">
                        <a href="#" class="dropdown-toggle" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false"> <i class="menu-icon fa fa-user"></i>UserName Manager</a>
                        <ul class="sub-menu children dropdown-menu">
                                 <li><i class="fa fa-users"></i><a href="users-list-usr">CheckList</a></li>
                            <li><i class="fa fa-user"></i><a href="register-user-usr">Registeration</a></li>
                            <li><i class="fa fa-user-plus"></i><a href="add-days">Update Days</a></li>
                            <li><i class="fa fa-unlock"></i><a href="trial">Trail</a></li>
                        </ul>
            
                                <li class="menu-title">Token Management</li><!-- /.menu-title -->

			
                    <li class="menu-item-has-children dropdown">
                        <a href="#" class="dropdown-toggle" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false"> <i class="menu-icon fa fa-user"></i>TokenKey Manager</a>
                        <ul class="sub-menu children dropdown-menu">
                                 <li><i class="fa fa-users"></i><a href="users-list-tkn">CheckList</a></li>
                            <li><i class="fa fa-user"></i><a href="register-user-tkn">Registeration</a></li>
                            <li><i class="fa fa-user-plus"></i><a href="add-days">Update Days</a></li>
                            <li><i class="fa fa-unlock"></i><a href="trial">Trail</a></li>
                        </ul>
            
                
                                <li class="menu-title">Other Management</li><!-- /.menu-title -->

                    <!-- Other Funtions -->

                    <li class="menu-item-has-children dropdown">
                        <a href="#" class="dropdown-toggle" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false"> <i class="menu-icon fa fa-money"></i>LibraryOnlineSystem</a>
                        <ul class="sub-menu children dropdown-menu">
                            <li><i class="fa fa-unlock-alt"></i><a href="tables-basic.html">Chat Online</a></li>
                            <li><i class="fa fa-unlock-alt"></i><a href="tables-data.html">Lib Online</a></li>
                            <li><i class="fa fa-unlock-alt"></i><a href="tables-data.html">Upload Lib</a></li>
                            <li><i class="fa fa-unlock-alt"></i><a href="tables-data.html">Status Lib</a></li>
                        </ul>

                    <li class="menu-title">Resell Management</li><!-- /.menu-title -->

                    <li class="menu-item-has-children dropdown">
                        <a href="#" class="dropdown-toggle" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false"> <i class="menu-icon fa fa-vcard"></i>Reselling Manager</a>
                        <ul class="sub-menu children dropdown-menu">
                            <li><i class="fa fa-sellsy"></i><a href="admin/detail_dashboard2.php">User Analytics</a></li>
                               <li><i class="fa fa-handshake-o"></i><a href="admin/reseller-core/register.php">Seller Register</a></li>
                            <li><i class="fa fa-users"></i><a href="admin/userlist.php">Sellerlist</a></li>
                        </ul>


  
                        
                        </ul>
                    </li>


                    
                </ul>
            </div><!-- /.navbar-collapse -->
        </nav>
    </aside>
    <!-- /#left-panel -->
    <!-- Right Panel -->
    <div id="right-panel" class="right-panel">
        <!-- Header-->
        <header id="header" class="header">
            <div class="top-left">
                <div class="navbar-header">
                    <a class="navbar-brand" href="./"><img src="../images/hackersteam.png" alt="Logo"></a>
                    <a class="navbar-brand hidden" href="./"><img src="../images/logo2.png" alt="Logo"></a>
                    <a id="menuToggle" class="menutoggle"><i class="fa fa-bars"></i></a>
                </div>
            </div>
            <div class="top-right">
                        
                    
                <div class="header-menu">
                    <div class="header-left">
                        <button class="search-trigger"><i class="fa fa-search"></i></button>
                        <div class="form-inline">
                            <form class="search-form">
                                <input class="form-control mr-sm-2" type="text" placeholder="Search ..." aria-label="Search">
                                <button class="search-close" type="submit"><i class="fa fa-close"></i></button>
                            </form>
                        </div>

                    <div class="user-area dropdown float-right">
                        <a href="#" class="dropdown-toggle active" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                        

       <?php
		$sql = "SELECT * from admin;";
		$query = $dbh -> prepare($sql);
		$query->execute();
		$result=$query->fetch(PDO::FETCH_OBJ);
		$cnt=1;	
?>


                            
                            
 
                            
                       
                         <img class="user-avatar rounded-circle" alt="User Avatar" src="../images/avatar/<?php echo htmlentities($result->image);?>">
                                             </a>
                           <div class="user-menu dropdown-menu">
                            <a class="nav-link" href="profile.php"><i class="fa fa-user"></i>My Profile</a>

                            <a class="nav-link" href="admin/notification.php"><i class="fa fa-bell"></i>Notifications <sup style="color:red">*</sup></a>
                            
                            

                            <a class="nav-link" href="#"><i class="fa fa-cog"></i>Settings</a>

                            <a class="nav-link" href="logout.php"><i class="menu-icon fa fa-sign-out"></i>Logout</a>

                        </div>
                    </div>

                </div>
            </div>
        </header>
        <!-- /#header -->
        



        </header>
        <!-- /#header -->
        <!-- Content -->
        <div class="content">
            <!-- Animated -->
            <div class="animated fadeIn">
        
                <!--  Traffic  -->
                <div class="row">
                    <div class="col-lg-12">
                     <div class="card">
                        <div class="card-header">
                              <div class="row">
                              <div class="col-lg-12">
                              <div class="card">
                              <div class="card-header">
                              <i class="mr-2 fa fa-align-justify"></i>
                                     <center>
                                    <strong class="card-title" v-if="headerText">Profile</strong>
                                     </center>
                                </div>

                                <div class="card-body">


                            
                            
                            <body>

    
        
    
    
    
<?php
		$sql = "SELECT * from admin;";
		$query = $dbh -> prepare($sql);
		$query->execute();
		$result=$query->fetch(PDO::FETCH_OBJ);
		$cnt=1;	
?>

		<div class="content-wrapper">
			<div class="container-fluid">
				<div class="row">
					<div class="col-md-12">
						<div class="row">
							<div class="col-md-12">
								<div class="panel panel-default">
								<!--	<div class="panel-heading"><?php echo htmlentities($_SESSION['logado']); ?></div> -->
<?php if($error){?><div class="errorWrap"><strong>ERROR</strong>:<?php echo htmlentities($error); ?> </div><?php } 
				else if($msg){?><div class="succWrap"><strong>SUCCESS</strong>:<?php echo htmlentities($msg); ?> </div><?php }?>

									<div class="panel-body">
<form method="post" class="form-horizontal" enctype="multipart/form-data">


	<div class="col-sm-4">
	</div>
	<div class="form-group">

		<center><img src="../images/avatar/<?php echo htmlentities($result->image);?>" style="width:200px; <!-- border-radius:50%; --> margin:10px;"></center>
	
			</div>
		<p class="form-control" style="text-align:center;">Profile Information</p>


		
<div class="form-group">
	<label class="col-sm-2 control-label">Avatar</label>
	<div class="input-group"><div class="input-group-addon"><i class="fa fa-file-image-o"></i></div>
     <input type="file" name="image" class="form-control" value="<?php echo htmlentities($result->image);?>">
     <input type="hidden" name="image" class="form-control" value="<?php echo htmlentities($result->image);?>">

	</div>









<div class="form-group">
	<label class="col-sm-2 control-label">Username</label>
	<div class="input-group"><div class="input-group-addon"><i class="fa fa-user-o"></i></div>
	<input type="text" name="name" class="form-control" required value="<?php echo htmlentities($result->name);?>">
	</div>

<div class="form-group">
	<label class="col-sm-2 control-label">Email</label>
	<div class="input-group"><div class="input-group-addon"><i class="fa fa-envelope-open-o"></i></div>
	<input type="email" name="email" class="form-control" required value="<?php echo htmlentities($result->email);?>">
	</div>

<div class="form-group">
	<label class="col-sm-2 control-label">Gender</label>
	<div class="input-group"><div class="input-group-addon"><i class="fa fa-child"></i></div>
    <input type="hidden" name="gender" class="form-control" required value="<?php echo htmlentities($result->gender);?>">
	                        <select class="form-control"
                            <option value="">Select</option>
                            <option value="Secret">Secret</option>
                            <option value="Female">Female</option>
                            <option value="Male">Male</option>
                            <option value="Other">Other</option>
                            </select>
	</div>

<div class="form-group">
	<label class="col-sm-2 control-label">Age</label>
	<div class="input-group"><div class="input-group-addon"><i class="fa fa-heartbeat"></i></div>
	<input type="text" name="age" class="form-control" required value="<?php echo htmlentities($result->age);?>">
	</div>

<div class="form-group">
	<label class="col-sm-2 control-label">Mobile</label>
	<div class="input-group"><div class="input-group-addon"><i class="fa fa-phone"></i></div>
	<input type="text" name="mobile" class="form-control" required value="<?php echo htmlentities($result->mobile);?>">
	</div>

	<label class="col-sm-2 control-label">Designation</label>
	<div class="input-group"><div class="input-group-addon"><i class="fa fa-map-marker"></i></div>
	<input type="text" name="designation" class="form-control" required value="<?php echo htmlentities($result->designation);?>">
	</div>
</div>
<input type="hidden" name="editid" class="form-control" required value="<?php echo htmlentities($result->id);?>">

<div class="form-group">
	<div class="col-sm-8 col-sm-offset-2">
		<button class="btn btn-primary" name="submit" type="submit" onclick="return confirm('Do you want to Confirm');">Save Changes</button>
	</div>
</div>

</form>
									</div>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
         
                            
                            
                            
                            
                            
                                    </div> <!-- /.card-body -->
                                </div>
                            </div> <!-- /.row -->
                            <div class="card-body"></div>
                        </div>
                    </div><!-- /# column -->
                </div>
                <!--  /Traffic -->
                <div class="clearfix"></div>
                <!-- Orders -->
                
            
        <!-- /.content -->
        <div class="clearfix"></div>
        <!-- Footer -->
        <footer class="site-footer">
            <div class="card">
            <div class="card-header">
            <div class="footer-inner bg-white">
                <div class="row">
                    <div class="col-sm-6"><B>
                        Copyright &copy; <a href="https://goxome.epizy.com"> 2021 Goxome
                    </div>
                </div>
            </div>
        </footer>
        <!-- /.site-footer -->
    </div>
    <!-- /#right-panel -->

    <!-- Scripts -->
    <script src="https://cdn.jsdelivr.net/npm/jquery@2.2.4/dist/jquery.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.14.4/dist/umd/popper.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.1.3/dist/js/bootstrap.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/jquery-match-height@0.7.2/dist/jquery.matchHeight.min.js"></script>
    <script src="../heartcore/assets/js/main.js"></script>

    <!--  Chart js -->
    <script src="https://cdn.jsdelivr.net/npm/chart.js@2.7.3/dist/Chart.bundle.min.js"></script>

    <!--Chartist Chart-->
    <script src="https://cdn.jsdelivr.net/npm/chartist@0.11.0/dist/chartist.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/chartist-plugin-legend@0.6.2/chartist-plugin-legend.min.js"></script>

    <script src="https://cdn.jsdelivr.net/npm/jquery.flot@0.8.3/jquery.flot.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/flot-pie@1.0.0/src/jquery.flot.pie.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/flot-spline@0.0.1/js/jquery.flot.spline.min.js"></script>

    <script src="https://cdn.jsdelivr.net/npm/simpleweather@3.1.0/jquery.simpleWeather.min.js"></script>
    <script src="../heartcore/assets/js/init/weather-init.js"></script>

    <script src="https://cdn.jsdelivr.net/npm/moment@2.22.2/moment.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/fullcalendar@3.9.0/dist/fullcalendar.min.js"></script>
    <script src="../heartcore/assets/js/init/fullcalendar-init.js"></script>

    <!--Local Stuff-->



</body>
</html>
