<?php 
// DB credentials.

define('DB_HOST','localhost');// SEVER
$servername = "localhost";

define('DB_USER','root');// USERNAME
$username = "root";

define('DB_PASS','');// DATABASEPASS
$password = "";

define('DB_NAME','db_admin');// DATABASENAME
$database = "db_admin";



// Establish database connection.
include("config2.php");//POD
include("config3.php");//SQLI

?>