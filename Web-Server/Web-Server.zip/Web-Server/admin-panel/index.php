<?php
// Conex���o
//require_once('anti_ddos/index.php');
include 'includes/config.php';
include 'heartcore/session/session.php';

// Sess���o
session_start();//-- if antdos enable session already started in antiddos

// Bot���o enviar
if(isset($_POST['btn-enter'])):
	$erros = array();
	$username = mysqli_escape_string($conn, $_POST['username']);
	$password = mysqli_escape_string($conn, $_POST['password']);

	if(isset($_POST['remember password'])):

		setcookie('username', $username, time()+3600);
		setcookie('password', md5($password), time()+3600);
	endif;

	if(empty($username) or empty($password)):
		$erros[] = "<li> The login/password field needs to be filled. </li>";
	else:
		// 105 OR 1=1 
	    // 1; DROP TABLE teste

		$sql = "SELECT username FROM admin WHERE username = '$username'";
		$resultado = mysqli_query($conn, $sql);		

		if(mysqli_num_rows($resultado) > 0):
		$password = md5($password);       
		$sql = "SELECT * FROM admin WHERE username = '$username' AND password = '$password'";



		$resultado = mysqli_query($conn, $sql);

			if(mysqli_num_rows($resultado) == 1):
				$dados = mysqli_fetch_array($resultado);
				mysqli_close($conn);
			//	$_SESSION["$sessao"] = true;
		        $_SESSION["logado"] = true;
				$_SESSION['logado'] = $dados['id'];
				header('Location: dashboard.php');
			else:
				$erros[] = "<li> Check it > Users and password </li>";
			endif;

		else:
			$erros[] = "<li> Non-existent User. </li>";
		endif;

	endif;

endif;
?>

<html lang="en">
<head><meta charset="euc-jp">
	<title>Login</title>
	
	<meta name="viewport" content="width=device-width, initial-scale=1">
<!--===============================================================================================-->	
	<link rel="icon" type="image/png" href="images2/icons/favicon.ico"/>
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="vendor2/bootstrap/css/bootstrap.min.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="heartcore/login_core_fonts/font-awesome-4.7.0/css/font-awesome.min.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="heartcore/login_core_fonts/iconic/css/material-design-iconic-font.min.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="vendor2/animate/animate.css">
<!--===============================================================================================-->	
	<link rel="stylesheet" type="text/css" href="vendor2/css-hamburgers/hamburgers.min.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="vendor2/animsition/css/animsition.min.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="vendor2/select2/select2.min.css">
<!--===============================================================================================-->	
	<link rel="stylesheet" type="text/css" href="vendor2/daterangepicker/daterangepicker.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="heartcore/css_login/util.css">
	<link rel="stylesheet" type="text/css" href="heartcore/css_login/main.css">
<!--===============================================================================================-->
</head>
<body>

		<div class="container-login100" style="background-image: url('images/template/background/goxome-background.png');">
		<!--	<div class="wrap-login100 p-l-55 p-r-55 p-t-65 p-b-54"> -->
				<form action="<?php echo $_SERVER['PHP_SELF']; ?>" method="POST" class="login100-form validate-form" >
					

					<span class="login100-form-title p-b-49">Login System</span>
					
					
					
					<?php 
if(!empty($erros)):
	foreach($erros as $erro):
		echo $erro;
	endforeach;
endif;
?>

						<div class="wrap-input100 validate-input m-b-23" data-validate = "Place the User!">
						    <span class="label-input100">User</span>
						<input class="input100" type="text" name="username" placeholder="Example : Goxome" value="<?php echo isset($_COOKIE['login']) ? $_COOKIE['login'] : '' ?>">
				       <span class="focus-input100" data-symbol="&#xf206;"></span>
					</div>

					<div class="wrap-input100 validate-input" data-validate="Coloque a password!">
					    <span class="label-input100">Password</span>
						<input class="input100" type="password" name="password" placeholder="Password : Goxome" value="<?php echo isset($_COOKIE['password']) ? $_COOKIE['password'] : '' ?>" >
							<span class="focus-input100" data-symbol="&#xf190;"></span>
					</div>
					
			
					
					
 <br></br>
						<div class="container-login100-form-btn">
						   
						<div class="wrap-login100-form-btn">
							<div class="login100-form-bgbtn"></div>
							<button class="login100-form-btn" type="submit" name="btn-enter">


								Login
							</button>
						</div>
				</form>
				<div class="text-center w-full">
			   <a class="text_bottom" href="http://Goxome.epizy.com" style="text-decoration: none;">Server by Goxome</font><br></strong></p></a>
			</div>
	</div>
	
	

	
<!--===============================================================================================-->	
	<script src="vendor2/jquery/jquery-3.2.1.min.js"></script>
<!--===============================================================================================-->
	<script src="vendor2/bootstrap/js/popper.js"></script>
	<script src="vendor2/bootstrap/js/bootstrap.min.js"></script>
<!--===============================================================================================-->
	<script src="vendor2/select2/select2.min.js"></script>
<!--===============================================================================================-->
	<script src="heartcore/js/login_main.js"></script>

</body>
</html>

