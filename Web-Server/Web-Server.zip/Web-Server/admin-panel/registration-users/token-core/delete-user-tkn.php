<?php
include '../../includes/config.php';
include '../../lipstick-core/Global.php';

if($maintenance == false){
     $conn->query("DELETE FROM `tokens` WHERE `Username` = '".$_GET['no']."'");   
}

?>

<script type="text/javascript">
	alert("Delete User");
	window.location.href='../users-list-tkn.php';
</script>