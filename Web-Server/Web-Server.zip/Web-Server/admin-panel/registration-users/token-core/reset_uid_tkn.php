<?php 
include '../../includes/config.php';

     $conn->query("UPDATE tokens SET UID=NULL");   
?>
<script type="text/javascript">
	alert("General reboot of users");
	window.location.href='../users-list-tkn';
</script>